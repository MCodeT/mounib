import 'package:flutter/material.dart';
import 'package:mounib/homeScreen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Food Inquery',
      routes: {
        "/principale": (context) => const HomeScreen(),
        // "/inscription": (context) => const PageInscription(),
        // "/connection": (context) => const PageConnexion(),
        // "/accueil": (context) => const Accueil(),
        // "/mdpoublie": (context) => const PageMdpOublie(),
        // "/profile": (context) => ProfileUtilisateur(
        //       apiKey: 'iso',
        //       apiUrl: 'https://onicall.vivaiitama.com',
        //     ),
        // "/params": (context) => PageAccueil(),
        // "/tier": (context) => Tiers(),
        // "/grh": (context) => PageModuleGRH(),
        // "/commande": (context) => CommandeListPage(),
      },
      debugShowCheckedModeBanner: false,
      initialRoute: "/principale",
    );
  }
}
